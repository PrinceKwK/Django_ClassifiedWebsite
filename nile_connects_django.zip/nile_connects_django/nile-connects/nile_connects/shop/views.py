from django.db import models
from django.http.response import HttpResponse
from django.shortcuts import render
from .models import Post,Categories
from django.db.models import Q

# Create your views here.


def index(request):
   context = Categories.objects.all()
   items = Post.objects.all()
   return render(request,'shop/home.html',{'categories': context,'items' : items });

def about(request):
   return render(request,'shop/about.html');



# query the search results
def search_venues(request):
   searched = request.POST['searched']
   venues = Post.objects.filter(Q(title__contains=searched) | Q(description__contains=searched) )
   result = { 'searched' : searched, 'venues': venues }

   if request.method == 'POST':
      return render(request,'shop/search_venues.html',result)
   else:
      return render(request,'shop/search_venues.html')
   
from django.contrib import admin
from .models import Post,Categories,Category_item,Post_image


admin.site.register(Post)
admin.site.register(Categories)
admin.site.register(Category_item)
admin.site.register(Post_image)


